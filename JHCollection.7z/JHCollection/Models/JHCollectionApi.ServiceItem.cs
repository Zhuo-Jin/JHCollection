﻿using JHCollection.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace JHCollectionApi.Models
{
    public class ServiceItem
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        public string ServiceCode { get; set; }

        public string ServiceDescription { get; set; }


        [Column(TypeName = "money")]
        public float ItemPrice { get; set; }

        public int UnitCost { get; set; }

        [JsonIgnore]
        [ForeignKey("Id")]
        public Guid UnitId { get; set; }
        public Unit Unit { get; set; }

        [JsonIgnore]
        [ForeignKey("Id")]
        public Guid StatusId { get; set; }
        public RefStatus Status { get; set; }

        [JsonIgnore]
        public ICollection<ScheduleItem> ScheduleItems { get; set; }

    }
}

﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace JHCollectionApi.Models
{
    public class JHDbContext : DbContext
    {
        public DbSet<Customer> Customers { get; set; }
        public DbSet<RefStatus> Statuses { get; set; }

        public DbSet<ServiceItem> ServiceItems { get; set; }

        public DbSet<Unit> Unit { get; set; }

        public DbSet<Schedule> Schedules { get; set; }

        public DbSet<ScheduleItem> ScheduleItems { get; set; }

        public DbSet<AuthUser> AuthUsers { get; set; }

        public JHDbContext(DbContextOptions<JHDbContext> Option) : base(Option) {


        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ScheduleItem>().HasOne<Schedule>(si => si.Schedule).WithMany(s => s.ScheduleItems).HasForeignKey(si => si.ScheduleId).OnDelete(DeleteBehavior.Restrict);
            modelBuilder.Entity<ScheduleItem>().HasOne<ServiceItem>(si => si.ServiceItem).WithMany(serv => serv.ScheduleItems).OnDelete(DeleteBehavior.Restrict);

        }
        

    }
}

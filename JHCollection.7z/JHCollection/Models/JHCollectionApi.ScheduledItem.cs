﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace JHCollectionApi.Models
{
    public class ScheduleItem
    {

        [JsonIgnore]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id{ get; set; }

        
        public Guid ScheduleId { get; set; }
        [JsonIgnore]
        public Schedule Schedule { get; set; }


        public Guid ServiceItemId { get; set; }
        public ServiceItem ServiceItem { get; set; }
    }
}

﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace JHCollectionApi.Models
{
    public class Schedule
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        public DateTime StartTime { get; set; }

        public DateTime FinishTime { get; set; }

        public int TotalUnitCost { get; set; }

        [Column(TypeName = "varchar(6)")]
        public string Token { get; set; }


        [ForeignKey("Id")]
        public Guid CustomerId { get; set; }
        public Customer Customer { get; set; }


        [ForeignKey("Id")]
        public Guid StatusId { get; set; }
        public RefStatus Status { get; set; }


        [ForeignKey("Id")]
        public Guid UnitId { get; set; }
        public Unit Unit { get; set; }


        public ICollection<ScheduleItem> ScheduleItems { get; set; }

    }
}

﻿using JHCollectionApi.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JHCollectionApi.Models
{
    public class AppointmentDateInput : IAppointmentDateInput
    {
        public Guid AppointmentGuid { get; set; }
        public DateTime AppointmentDate { get; set; }
    }
}

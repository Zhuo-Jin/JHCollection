﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace JHCollectionApi.Models
{

    //for token login user, not expose to public
    public class AuthUser
    {
        [Key]
        public Guid Id { get; set; }

        public String UserName { get; set; }

        public string Password { get; set; }


    }
}

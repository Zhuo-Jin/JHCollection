﻿using JHCollectionApi.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JHCollectionApi.Models
{
    public class AppointmentItemForDisplay : IAppointmentItem
    {
        public IEnumerable<string> DisplayItemsInRow { get; set; } 
    }
}

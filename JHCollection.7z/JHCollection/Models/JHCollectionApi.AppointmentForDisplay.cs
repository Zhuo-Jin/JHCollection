﻿using JHCollectionApi.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JHCollectionApi.Models
{
    public class AppointmentForDisplay : IAppointment
    {
        public IEnumerable<IAppointmentItem> AppointmentItems { get; set; }
        public DateTime WorkTimeStart { get; set; }
        public DateTime WorkTimeFinish { get; set; }
        public int TimeUnitInMin { get; set; }
        public IEnumerable<string> Header { get; set; }
    }
}

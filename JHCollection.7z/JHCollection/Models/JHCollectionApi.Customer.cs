﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace JHCollectionApi.Models
{
    public class Customer
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid  Id { get; set; }

        [Column(TypeName = "nvarchar(255)")]
        public string Firstname { get; set; }

        [Column(TypeName = "nvarchar(255)")]
        public string Surname { get; set; }

        [Column(TypeName ="varchar(10)")]
        public string Mobile { get; set; }

        public string Email { get; set; }

        public bool IsAdmin { get; set; }

        [ForeignKey("Id")]
        public Guid StatusId { get; set; }

        public RefStatus Status { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JHCollectionApi.Interface
{
    public interface IAppointment
    {
        DateTime WorkTimeStart { get; set; }
        DateTime WorkTimeFinish { get; set; }

        IEnumerable<string> Header { get; set; }
        int TimeUnitInMin { get; set; }

        IEnumerable<IAppointmentItem> AppointmentItems { get; set; }


    }
}

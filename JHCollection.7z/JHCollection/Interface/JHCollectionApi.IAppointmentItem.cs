﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JHCollectionApi.Interface
{
    public interface IAppointmentItem
    {
        IEnumerable<string> DisplayItemsInRow { get; set; }

    }
}

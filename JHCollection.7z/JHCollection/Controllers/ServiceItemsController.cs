﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using JHCollectionApi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;

namespace JHCollectionApi.Controllers
{
    
    [Route("api/[controller]")]
    [ApiController]
    public class ServiceItemsController : ControllerBase
    {
        private readonly JHDbContext _context;

        public ServiceItemsController(JHDbContext context)
        {
            _context = context;
        }

        // GET: api/ServiceItems
        [HttpGet]
        public IEnumerable<ServiceItem> GetServiceItems()
        {
            var statusId = _context.Statuses.Where(s => s.StatusName == "Active").Select(s=> s.Id).FirstOrDefault();

            return _context.ServiceItems.Where(si => si.StatusId == statusId).Include(s => s.Unit);
        }

        // GET: api/ServiceItems/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetServiceItem([FromRoute] Guid id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var serviceItem = await _context.ServiceItems.FindAsync(id);

            if (serviceItem == null)
            {
                return NotFound();
            }

            return Ok(serviceItem);
        }

        [Authorize]
        // PUT: api/ServiceItems/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutServiceItem([FromRoute] Guid id, [FromBody] ServiceItem serviceItem)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != serviceItem.Id)
            {
                return BadRequest();
            }

            _context.Entry(serviceItem).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ServiceItemExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/ServiceItems
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> PostServiceItem([FromBody] ServiceItem serviceItem)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _context.ServiceItems.Add(serviceItem);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetServiceItem", new { id = serviceItem.Id }, serviceItem);
        }

        // DELETE: api/ServiceItems/5
        [HttpDelete("{id}")]
        [Authorize]
        public async Task<IActionResult> DeleteServiceItem([FromRoute] Guid id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var serviceItem = await _context.ServiceItems.FindAsync(id);
            if (serviceItem == null)
            {
                return NotFound();
            }

            _context.ServiceItems.Remove(serviceItem);
            await _context.SaveChangesAsync();

            return Ok(serviceItem);
        }

        [Authorize]
        private bool ServiceItemExists(Guid id)
        {
            return _context.ServiceItems.Any(e => e.Id == id);
        }
    }
}
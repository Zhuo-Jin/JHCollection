﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using JHCollectionApi.Interface;
using JHCollectionApi.Models;
using JHCollectionApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace JHCollectionApi.Controllers
{
    [Authorize]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class AppointmentsController : ControllerBase
    {

        private readonly string _timeToStart = "9:00:00";
        private readonly int _workingHours = 8;



        private readonly JHDbContext _context;
        public AppointmentsController(JHDbContext context)
        {
            _context = context;
            
        }


        [HttpGet("{AppointmentId}")]
        public async Task<IActionResult> GetScheduleItemsFromAppointmentId([FromRoute] Guid AppointmentId)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var scheduleItems = await _context.ScheduleItems.Where(s => s.ScheduleId == AppointmentId).Select(s => s.ServiceItemId).ToListAsync<Guid>();
            IEnumerable<ServiceItem> serviceItems = await _context.ServiceItems.Where(si => scheduleItems.Contains(si.Id)).ToListAsync();

            if (scheduleItems == null)
            {
                return Ok(new List<ServiceItem>());
            }

            return Ok(serviceItems);
        }

        [HttpGet("{Date}")]
        public async Task<IActionResult> GetCurrentAppointments([FromRoute] string Date)
        {
            var serviceUnit = _context.Unit.FirstOrDefault().UnitInMin;
            var startDateTime = DateTime.Parse(Date + " " + _timeToStart);

            var schedules = await _context.Schedules.Where(s => s.StartTime >= startDateTime.AddDays(-1) && s.FinishTime < startDateTime.AddDays(2)).ToArrayAsync();


            var appointment = new AppointmentForDisplay()
            {
                Header = new List<string>() {"", startDateTime.AddDays(-1).ToString("yyyy-MM-dd"), startDateTime.ToString("yyyy-MM-dd"), startDateTime.AddDays(1).ToString("yyyy-MM-dd") },
                TimeUnitInMin = serviceUnit,
                WorkTimeStart = startDateTime,
                WorkTimeFinish = startDateTime.AddHours(_workingHours),
                AppointmentItems = GetAllRecentAppointments(startDateTime, serviceUnit, schedules)
            };

             
            return Ok(appointment);

        }


        [HttpGet("{AppointmentId}/{Code}")]
        public async Task<IActionResult> ValidateAccessCode([FromRoute]Guid AppointmentId,  string Code)
        {
            var schedule = await _context.Schedules.FindAsync(AppointmentId);
            return Ok(schedule == null ? false : (schedule.Token == Code ? true : false));
        }

        [HttpGet("{Date}/{CurrentScheduleId}")]
        public async Task<IActionResult> GetAvailableTimeListFromDate([FromRoute] string Date, Guid CurrentScheduleId)
        {
            var serviceUnit = _context.Unit.FirstOrDefault().UnitInMin;
            var startDateTime = DateTime.Parse(Date + " " + _timeToStart);
            var workFinishTime = startDateTime.AddHours(this._workingHours);

            var schedules = await _context.Schedules.Where(s => s.StartTime >= startDateTime && s.FinishTime < workFinishTime && s.Id != CurrentScheduleId).ToArrayAsync();

            var listOfAvailableString = new List<string>();

            while (startDateTime <= workFinishTime)
            {
                if (!schedules.Any(s => startDateTime >= s.StartTime && startDateTime <= s.FinishTime))
                {
                    listOfAvailableString.Add(startDateTime.ToString("HH:mm"));
                }

                startDateTime = startDateTime.AddMinutes(serviceUnit);
            }

            return Ok(listOfAvailableString);

        }

        [HttpGet("{Date}/{Time}/{CurrentScheduleId}")]
        public async Task<IActionResult> GetAvailableUnitsFromDateAndTime([FromRoute] string Date, string Time, Guid CurrentScheduleId)
        {
            var serviceUnit = _context.Unit.FirstOrDefault().UnitInMin;

            Time = Regex.Replace(Time, @"(\d{1,2})(\d\d)", "$1:$2");

            var startDateTime = DateTime.Parse(Date + " " + Time);
            var workFinishTime = DateTime.Parse(Date + " " + _timeToStart).AddHours(this._workingHours);

            var nearestSchedule = await _context.Schedules
                .Where(s => s.StartTime >= startDateTime &&  s.Id != CurrentScheduleId)
                .OrderBy(s => s.StartTime)
                .FirstOrDefaultAsync();

            TimeSpan sp = nearestSchedule != null ? nearestSchedule.StartTime - startDateTime : workFinishTime - startDateTime;

            return Ok(Convert.ToInt16(sp.TotalMinutes) / serviceUnit);

        }



        public IEnumerable<IAppointmentItem> GetAllRecentAppointments(DateTime DateTimeSelected, int Unit, IEnumerable<Schedule> schedules)
        {

            var startTime = DateTime.Parse(DateTimeSelected.ToString());

            var listOfAppointment = new List<IAppointmentItem>();


            while (startTime <= DateTimeSelected.AddHours(_workingHours)) {


                var appItem = new AppointmentItemForDisplay() {
                                                                    DisplayItemsInRow = new string[] {
                                                                        startTime.ToString("HH:mm"),
                                                                        BookedCustomer(startTime.AddDays(-1), schedules),
                                                                        BookedCustomer(startTime, schedules),
                                                                        BookedCustomer(startTime.AddDays(1), schedules)
                                                                    }

                                                                };

                listOfAppointment.Add(appItem);
                startTime = startTime.AddMinutes(Unit);
            }

            return listOfAppointment;

        }

        public string BookedCustomer(DateTime currentTime, IEnumerable<Schedule> schedules)
        {
            var schedule = schedules.Where(s => currentTime >= s.StartTime && currentTime < s.FinishTime)?
                            .FirstOrDefault();

            if (currentTime.DayOfWeek == DayOfWeek.Sunday)
            {
                // return a dummy one disable the weekend
                return Guid.NewGuid().ToString() + "|" + Guid.NewGuid().ToString();
            }
            else {
                return ((schedule == null || schedule.Id == Guid.Empty) ? "" : schedule.Id.ToString() + "|" + schedule.CustomerId.ToString());
            }
        }

        
    }
}
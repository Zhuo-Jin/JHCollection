﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using JHCollectionApi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;

namespace JHCollectionApi.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class ScheduleItemsController : ControllerBase
    {
        private readonly JHDbContext _context;

        public ScheduleItemsController(JHDbContext context)
        {
            _context = context;
        }

        // GET: api/ScheduleItems
        [HttpGet]
        
        public IEnumerable<ScheduleItem> GetScheduleItems()
        {
            return _context.ScheduleItems;
        }

        // GET: api/ScheduleItems/5
        [HttpGet("{id}")]
        
        public async Task<IActionResult> GetScheduleItem([FromRoute] Guid id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var scheduleItem = await _context.ScheduleItems.FindAsync(id);

            if (scheduleItem == null)
            {
                return NotFound();
            }

            return Ok(scheduleItem);
        }

        // PUT: api/ScheduleItems/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutScheduleItem([FromRoute] Guid id, [FromBody] ScheduleItem scheduleItem)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != scheduleItem.Id)
            {
                return BadRequest();
            }

            _context.Entry(scheduleItem).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ScheduleItemExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/ScheduleItems
        [HttpPost]
        public async Task<IActionResult> PostScheduleItem([FromBody] ScheduleItem scheduleItem)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _context.ScheduleItems.Add(scheduleItem);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetScheduleItem", new { id = scheduleItem.Id }, scheduleItem);
        }


        


        // DELETE: api/ScheduleItems/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteScheduleItem([FromRoute] Guid id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var scheduleItem = await _context.ScheduleItems.FindAsync(id);
            if (scheduleItem == null)
            {
                return NotFound();
            }

            _context.ScheduleItems.Remove(scheduleItem);
            await _context.SaveChangesAsync();

            return Ok(scheduleItem);
        }

        private bool ScheduleItemExists(Guid id)
        {
            return _context.ScheduleItems.Any(e => e.Id == id);
        }
    }
}
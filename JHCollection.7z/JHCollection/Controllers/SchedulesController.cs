﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using JHCollectionApi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using JHCollectionApi.Services;
using Microsoft.Extensions.Configuration;

namespace JHCollectionApi.Controllers
{

    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class SchedulesController : ControllerBase
    {
        private readonly JHDbContext _context;
        private readonly EmailService _emailService;

        public SchedulesController(JHDbContext context, IConfiguration configuration)
        {
            _context = context;
            _emailService = new EmailService(configuration.GetSection("EmailConfiguration").Get<EmailConfiguration>());
        }

        // GET: api/Schedules
        
        [HttpGet]
        public IEnumerable<Schedule> GetSchedules()
        {
            return _context.Schedules.Include(s => s.Unit).Include(s => s.Customer).Include(s => s.ScheduleItems).ThenInclude(si => si.ServiceItem);
        }

        // GET: api/Schedules/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetSchedule([FromRoute] Guid id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var schedule = await _context.Schedules.Include(s => s.Unit).Include(s => s.Customer).FirstOrDefaultAsync(s => s.Id == id);

            if (schedule == null)
            {
                return NotFound();
            }

            return Ok(schedule);
        }

        

        // PUT: api/Schedules/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutSchedule([FromRoute] Guid id, [FromBody] Schedule schedule)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != schedule.Id)
            {
                return BadRequest();
            }

            _context.Entry(schedule).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ScheduleExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }


            return NoContent();
        }

        // POST: api/Schedules
        [HttpPost]
        public async Task<IActionResult> PostSchedule([FromBody] Schedule schedule)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _context.Schedules.Add(schedule);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetSchedule", new { id = schedule.Id }, schedule);
        }

        [HttpPost("SendEmailNotification/{id}")]
        public async Task<IActionResult> SendEmailNotification([FromRoute] Guid id, [FromBody] EmailAddress email)
        {
            try
            {
                var schedule = await _context.Schedules.FindAsync(id);

                if (schedule != null)
                {
                    await SendEmail(schedule, email);
                    return Ok();

                }

                return NotFound($"Cannot find schedule ID [{id.ToString()}]");

            }
            catch (Exception ex)
            {
                throw ex;
            }

            
        }



        [HttpPost("UpsertSchedule")]
        public async Task<IActionResult> UpsertSchedule([FromBody] Schedule schedule)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // calculate finish time
            schedule.FinishTime = schedule.StartTime.AddMinutes(schedule.TotalUnitCost * _context.Unit.FirstOrDefault().UnitInMin);

            var ifExistSchedule = await _context.Schedules.AnyAsync(s => s.Id == schedule.Id);

            // whatever reason , regenerate code for security purpose
            Random generator = new Random();
            schedule.Token = generator.Next(100001, 999999).ToString("D6");

            // add cusotmer
            if (!ifExistSchedule)
            {
                // get access code
                await _context.Schedules.AddAsync(schedule);

                if (schedule.ScheduleItems != null)
                    await _context.ScheduleItems.AddRangeAsync(schedule.ScheduleItems);
            }
            else //update 
            {
                _context.Entry(schedule).State = EntityState.Modified;

                if (schedule.ScheduleItems != null)
                {

                    if (_context.ScheduleItems.Any(si => si.ScheduleId == schedule.Id))
                    {
                        _context.ScheduleItems.RemoveRange(_context.ScheduleItems.Where(si => si.ScheduleId == schedule.Id));
                        await _context.SaveChangesAsync();
                        
                    }

                    // for some reason the deleted schedule items has been merged back to the schedule ready to submit which cause duplication 
                    // use si => si.Id == Guid.Empty remove the duplication 
                    await _context.ScheduleItems.AddRangeAsync(schedule.ScheduleItems.Where(si => si.Id == Guid.Empty));
                    
                }
            }
            try
            {
                await _context.SaveChangesAsync();

                await SendEmail(schedule);

                return CreatedAtAction("GetSchedule", new { id = schedule.Id }, schedule);

            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ScheduleExists(schedule.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
        }

        // DELETE: api/Schedules/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSchedule([FromRoute] Guid id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var schedule = await _context.Schedules.FindAsync(id);
            if (schedule == null)
            {
                return NotFound();
            }



            _context.ScheduleItems.RemoveRange(_context.ScheduleItems.Where(si => si.ScheduleId == id));
            _context.Schedules.Remove(schedule);
            await _context.SaveChangesAsync();

            return Ok(schedule);
        }

        private bool ScheduleExists(Guid id)
        {
            return _context.Schedules.Any(e => e.Id == id);
        }

        private async Task SendEmail(Schedule schedule, EmailAddress email = null)
        {
            var customer = await _context.Customers.FindAsync(schedule.CustomerId);

            var emailMessage = new EmailMessage();
            emailMessage.FromAddresses.Add(new EmailAddress { Name = "Jenny's Hair Salon", Address = "No-reply@JennyHair.com" });
            emailMessage.Subject =  $"Your Booking on {schedule.StartTime.ToString("yyyy-MM-dd hh:mm:ss") } Has Been Confirmed";
            emailMessage.Content =  $"<HTML><p>Dear {(customer.Firstname != "" || customer.Surname != "" ? customer.Firstname + " " + customer.Surname : "Customer")}</p>" + 
                                    $"<br/>" + 
                                    $"<p>Your Access Code is {schedule.Token}</p>" + 
                                    $"<p><u>Access code can be used for the update of the appointment<u></p>" +
                                    $"<br/>" +
                                    $"<p>Thanks</p>" +
                                    $"Jenny's Hair Salon Group" + 
                                    "</HTML>";


            if (email != null)
            {
                emailMessage.ToAddresses.Add(email);
                _emailService.Send(emailMessage);
            }

            if (customer != null && customer.Email != "")
            {
               
                emailMessage.ToAddresses.Add(new EmailAddress { Name = (customer.Firstname != "" || customer.Surname != "" ? customer.Firstname + " " + customer.Surname : "Customer"), Address = customer.Email });
                _emailService.Send(emailMessage);

            }
        }
    }
}
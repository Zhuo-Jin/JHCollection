﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using JHCollectionApi.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using System.Security.Cryptography;
using JHCollection.Models;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Cors;

namespace JHCollectionApi.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class AuthTokenController : ControllerBase
    {
        private readonly JHDbContext _context;
        private readonly JwtAuthentication _jwtSettings;

        public AuthTokenController(JHDbContext context, IOptions<JwtAuthentication> jwtAuthenticationSetting)
        {
            _context = context;
            _jwtSettings = jwtAuthenticationSetting.Value;
        }

        // GET: api/AuthToken
        [Route("Token")]
        [HttpPost]
        public IActionResult Token([FromBody]AuthUser user)
        {
            
            if (!ModelState.IsValid) return BadRequest("Token failed to generate");
            var userIdentified = _context.AuthUsers.FirstOrDefault(u => u.UserName == user.UserName &&
                                                                        u.Password == GetSHA256Hash(user.Password ?? ""));
            if (userIdentified == null)
            {
                return Unauthorized();
            }
            

            user = userIdentified;

            //Add Claims
            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.UniqueName, "data"),
                new Claim(JwtRegisteredClaimNames.Sub, "data"),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtSettings.SecurityKey)); //Secret
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(_jwtSettings.ValidIssuer,
                _jwtSettings.ValidAudience,
                claims,
                expires: DateTime.Now.AddMinutes(30),
                signingCredentials: creds);

            return Ok(new
            {
                access_token = new JwtSecurityTokenHandler().WriteToken(token),
                expires_in = DateTime.Now.AddMinutes(_jwtSettings.ExpireInMins),
                token_type = "bearer"
            });
        }


        public static string GetSHA256Hash(string inputPassword)
        {
            byte[] data = Encoding.UTF8.GetBytes(inputPassword);

            using (SHA256 sha256Hash = SHA256.Create())
            {
                return BitConverter.ToString(sha256Hash.ComputeHash(data)).Replace("-", string.Empty);
            }
        }



    }
}
﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace JHCollectionApi.Migrations
{
    public partial class addtotalunitcostinscheduletable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "TotalUnitCost",
                table: "Schedules",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "TotalUnitCost",
                table: "Schedules");
        }
    }
}

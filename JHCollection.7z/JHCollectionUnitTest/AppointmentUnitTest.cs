using System;
using Xunit;
using JHCollectionApi.Controllers;
using JHCollectionApi.Models;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;


namespace JHCollectionUnitTest
{
    public class AppointmentUnitTest
    {
        private JHDbContext _context;
        private AppointmentsController _appointmentsController;

        public static IEnumerable<object[]> AppointmentData =>
           new List<object[]>
           {
                new object[] { DateTime.Parse("2019-09-02 09:00"), new List<Schedule>() { new Schedule() {
                        Id = new Guid("12f228dd-ef7f-43d7-9b70-3fb56e50240d"),
                        StartTime = DateTime.Parse("2019-09-02 09:00"),
                        FinishTime = DateTime.Parse("2019-09-02 10:00"),
                        CustomerId = new Guid("3f49fd0f-01ae-48cf-9f4f-cd858ba379ff"),
                        
                    } }  },
           };


        public static IEnumerable<object[]> AppointmentDataEmpty =>
           new List<object[]>
           {
                new object[] { DateTime.Parse("2019-09-02 11:00"), new List<Schedule>() { new Schedule() {
                        Id = new Guid("12f228dd-ef7f-43d7-9b70-3fb56e50240d"),
                        StartTime = DateTime.Parse("2019-09-02 09:00"),
                        FinishTime = DateTime.Parse("2019-09-02 10:00"),
                        CustomerId = new Guid("3f49fd0f-01ae-48cf-9f4f-cd858ba379ff"),

                    } }  },
           };


        [Theory]
        [MemberData(nameof(AppointmentData))]
        public void Appointment_BookedCustomer_NonWeekend_NonEmpty(DateTime currentTime, List<Schedule> schedules)
        {

            _appointmentsController = new AppointmentsController(_context);

            var result = _appointmentsController.BookedCustomer(currentTime, schedules);
            var expected = "12f228dd-ef7f-43d7-9b70-3fb56e50240d|3f49fd0f-01ae-48cf-9f4f-cd858ba379ff";

            Assert.Equal(expected, result);
        }

        [Theory]
        [MemberData(nameof(AppointmentDataEmpty))]
        public void Appointment_BookedCustomer_NonWeekend_Empty(DateTime currentTime, List<Schedule> schedules)
        {
            _appointmentsController = new AppointmentsController(_context);
            
            var result = _appointmentsController.BookedCustomer(currentTime, schedules);
            var expected = "";

            Assert.Equal(expected, result);
        }

        

    }

}
